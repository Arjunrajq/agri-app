import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertDealerSchema, insertShopSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Dealers routes
  app.get("/api/dealers", async (_req, res) => {
    const dealers = await storage.getDealers();
    res.json(dealers);
  });

  app.post("/api/dealers", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const parsed = insertDealerSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json(parsed.error);
    }

    const dealer = await storage.createDealer({
      ...parsed.data,
      userId: req.user.id,
    });
    res.status(201).json(dealer);
  });

  // Shops routes
  app.get("/api/shops", async (_req, res) => {
    const shops = await storage.getShops();
    res.json(shops);
  });

  app.post("/api/shops", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const parsed = insertShopSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json(parsed.error);
    }

    const shop = await storage.createShop(parsed.data);
    res.status(201).json(shop);
  });

  // Diseases routes
  app.get("/api/diseases", async (_req, res) => {
    const diseases = await storage.getDiseases();
    res.json(diseases);
  });

  app.get("/api/diseases/:id", async (req, res) => {
    const disease = await storage.getDisease(parseInt(req.params.id));
    if (!disease) return res.sendStatus(404);
    res.json(disease);
  });

  // Products routes
  app.get("/api/products", async (_req, res) => {
    const products = await storage.getProducts();
    res.json(products);
  });

  app.get("/api/products/:id", async (req, res) => {
    const product = await storage.getProduct(parseInt(req.params.id));
    if (!product) return res.sendStatus(404);
    res.json(product);
  });

  // Orders routes
  app.post("/api/orders", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const order = await storage.createOrder(
        req.user.id,
        req.body.items,
        req.body.shippingAddress
      );
      res.status(201).json(order);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/orders", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const orders = await storage.getOrders(req.user.id);
    const ordersWithItems = await Promise.all(
      orders.map(async (order) => ({
        ...order,
        items: await storage.getOrderItems(order.id),
      }))
    );
    res.json(ordersWithItems);
  });

  // User language preference
  app.patch("/api/user/language", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const { language } = req.body;
    if (language !== "en" && language !== "ta") {
      return res.status(400).json({ message: "Invalid language code" });
    }

    const user = await storage.updateUserLanguage(req.user.id, language);
    res.json(user);
  });

  // Add the weather route
  app.get("/api/weather", async (req, res) => {
    const { location } = req.query;

    if (!location) {
      return res.status(400).json({ message: "Location is required" });
    }

    try {
      const geocodeUrl = `http://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(location as string)}&limit=1&appid=${process.env.OPENWEATHER_API_KEY}`;
      const geocodeRes = await fetch(geocodeUrl);
      const geocodeData = await geocodeRes.json();

      if (!geocodeData.length) {
        return res.status(404).json({ message: "Location not found" });
      }

      const { lat, lon } = geocodeData[0];
      const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&appid=${process.env.OPENWEATHER_API_KEY}`;
      const weatherRes = await fetch(weatherUrl);
      const weatherData = await weatherRes.json();

      // Generate crop recommendations based on weather conditions
      const recommendations = getCropRecommendations(weatherData);

      res.json({
        temperature: weatherData.main.temp,
        humidity: weatherData.main.humidity,
        windSpeed: weatherData.wind.speed,
        description: weatherData.weather[0].description,
        recommendations,
      });
    } catch (error) {
      console.error("Weather API error:", error);
      res.status(500).json({ message: "Failed to fetch weather data" });
    }
  });

  // Helper function to generate crop recommendations
  function getCropRecommendations(weatherData: any) {
    const temp = weatherData.main.temp;
    const humidity = weatherData.main.humidity;
    const recommendations = [];

    if (temp < 20) {
      recommendations.push(
        "Current temperature is suitable for wheat and peas cultivation.",
        "Consider protecting sensitive crops from cold weather."
      );
    } else if (temp >= 20 && temp < 30) {
      recommendations.push(
        "Ideal temperature for most crops including paddy, tomatoes, and sunflowers.",
        "Maintain regular irrigation schedule."
      );
    } else {
      recommendations.push(
        "High temperature detected. Increase irrigation frequency.",
        "Consider shade protection for sensitive crops."
      );
    }

    if (humidity > 80) {
      recommendations.push(
        "High humidity may increase disease risk. Monitor for fungal infections.",
        "Ensure good air circulation in crop area."
      );
    } else if (humidity < 40) {
      recommendations.push(
        "Low humidity may cause water stress. Consider additional irrigation.",
        "Mulching can help retain soil moisture."
      );
    }

    return recommendations;
  }

  const httpServer = createServer(app);
  return httpServer;
}