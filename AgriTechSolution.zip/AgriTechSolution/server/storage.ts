import session from "express-session";
import createMemoryStore from "memorystore";
import { User, InsertUser, Dealer, Shop, Disease } from "@shared/schema";
import {Product, Order, OrderItem} from "@shared/schema"; // Assuming these are defined elsewhere

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  sessionStore: session.Store;
  
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserLanguage(userId: number, language: string): Promise<User>;

  // Dealer operations
  getDealers(): Promise<Dealer[]>;
  getDealer(id: number): Promise<Dealer | undefined>;
  createDealer(dealer: Omit<Dealer, "id">): Promise<Dealer>;
  
  // Shop operations
  getShops(): Promise<Shop[]>;
  getShop(id: number): Promise<Shop | undefined>;
  createShop(shop: Omit<Shop, "id">): Promise<Shop>;
  
  // Disease operations
  getDiseases(): Promise<Disease[]>;
  getDisease(id: number): Promise<Disease | undefined>;

  // Product operations
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: Omit<Product, "id">): Promise<Product>;

  // Order operations
  createOrder(userId: number, items: Array<{ productId: number; quantity: number }>, shippingAddress: string): Promise<Order>;
  getOrders(userId: number): Promise<Order[]>;
  getOrderItems(orderId: number): Promise<OrderItem[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private dealers: Map<number, Dealer>;
  private shops: Map<number, Shop>;
  private diseases: Map<number, Disease>;
  private products: Map<number, Product>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  sessionStore: session.Store;
  private currentId: number;

  constructor() {
    this.users = new Map();
    this.dealers = new Map();
    this.shops = new Map();
    this.diseases = new Map();
    this.products = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    this.currentId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });

    // Seed some initial disease data
    this.diseases.set(1, {
      id: 1,
      name: "Leaf Blight",
      description: "Common fungal disease affecting crop leaves",
      symptoms: ["Yellow patches", "Brown spots", "Wilting"],
      treatment: "Apply fungicide and ensure proper drainage",
      imageUrl: "https://images.unsplash.com/photo-1607326207820-989c6d53a0a2",
    });

    // Seed some shop data
    this.shops.set(1, {
      id: 1,
      name: "Farm Supply Co",
      description: "Complete farming supplies and fertilizers",
      address: "123 Farm Road",
      lat: "40.7128",
      lng: "-74.0060",
      contact: "555-0123",
    });

    // Seed dealer data
    this.dealers.set(1, {
      id: 1,
      userId: 1,
      name: "Green Farm Supplies",
      description: "Your one-stop shop for all farming needs",
      contact: "555-0101",
      location: "123 Agriculture Road, Chennai",
      services: ["Fertilizer Supply", "Seed Distribution", "Farm Equipment"],
    });

    this.dealers.set(2, {
      id: 2,
      userId: 2,
      name: "Agro Solutions",
      description: "Expert agricultural solutions and supplies",
      contact: "555-0102",
      location: "456 Farmers Street, Coimbatore",
      services: ["Organic Fertilizers", "Premium Seeds", "Farming Consultation"],
    });

    this.dealers.set(3, {
      id: 3,
      userId: 3,
      name: "Tamil Nadu Agri Center",
      description: "Local agricultural supplies and support",
      contact: "555-0103",
      location: "789 Market Road, Madurai",
      services: ["Seed Supply", "Pesticides", "Farming Tools"],
    });

    this.dealers.set(4, {
      id: 4,
      userId: 4,
      name: "Harvest Helper",
      description: "Supporting farmers with quality products",
      contact: "555-0104",
      location: "321 Rural Avenue, Salem",
      services: ["Farm Equipment Rental", "Seeds", "Fertilizers", "Technical Support"],
    });

    this.dealers.set(5, {
      id: 5,
      userId: 5,
      name: "Farmers Friend",
      description: "Trusted partner for agricultural needs",
      contact: "555-0105",
      location: "654 Garden Street, Trichy",
      services: ["Organic Products", "Modern Equipment", "Farmer Training"],
    });
    this.currentId = 6; // Update currentId after adding dealers


    // Seed product data
    this.products.set(1, {
      id: 1,
      name: "Organic Fertilizer",
      nameTA: "இயற்கை உரம்",
      category: "FERTILIZER",
      description: "High-quality organic fertilizer for all crops",
      descriptionTA: "அனைத்து பயிர்களுக்கும் உயர்தர இயற்கை உரம்",
      price: "499.99",
      stock: 100,
      imageUrl: "https://images.unsplash.com/photo-1585314062340-f1a5a7c9328d"
    });

    this.products.set(2, {
      id: 2,
      name: "Paddy Seeds",
      nameTA: "நெல் விதைகள்",
      category: "SEEDS",
      description: "High-yield paddy seeds",
      descriptionTA: "அதிக மகசூல் தரும் நெல் விதைகள்",
      price: "299.99",
      stock: 50,
      imageUrl: "https://images.unsplash.com/photo-1586201375761-83865001e31c"
    });
    this.products.set(3, {
      id: 3,
      name: "Wheat Seeds",
      nameTA: "கோதுமை விதைகள்",
      category: "SEEDS",
      description: "Premium quality wheat seeds for better yield",
      descriptionTA: "அதிக மகசூலுக்கான உயர்தர கோதுமை விதைகள்",
      price: "399.99",
      stock: 75,
      imageUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b"
    });

    this.products.set(4, {
      id: 4,
      name: "Sunflower Seeds",
      nameTA: "சூரியகாந்தி விதைகள்",
      category: "SEEDS",
      description: "High-quality sunflower seeds for cultivation",
      descriptionTA: "பயிருக்கான உயர்தர சூரியகாந்தி விதைகள்",
      price: "299.99",
      stock: 60,
      imageUrl: "https://images.unsplash.com/photo-1597831715190-25bb5599dbea"
    });

    this.products.set(5, {
      id: 5,
      name: "Pumpkin Seeds",
      nameTA: "பரங்கிக்காய் விதைகள்",
      category: "SEEDS",
      description: "Premium pumpkin seeds for farming",
      descriptionTA: "விவசாயத்திற்கான தரமான பரங்கிக்காய் விதைகள்",
      price: "249.99",
      stock: 45,
      imageUrl: "https://images.unsplash.com/photo-1569244769134-80380aa8c0de"
    });

    this.products.set(6, {
      id: 6,
      name: "Chickpeas Seeds",
      nameTA: "கொண்டைக்கடலை விதைகள்",
      category: "SEEDS",
      description: "High-yield chickpea seeds",
      descriptionTA: "அதிக மகசூல் தரும் கொண்டைக்கடலை விதைகள்",
      price: "199.99",
      stock: 80,
      imageUrl: "https://images.unsplash.com/photo-1515543904379-3d757afe72e3"
    });

    this.products.set(7, {
      id: 7,
      name: "Watermelon Seeds",
      nameTA: "தர்பூசணி விதைகள்",
      category: "SEEDS",
      description: "Quality watermelon seeds for farming",
      descriptionTA: "விவசாயத்திற்கான தரமான தர்பூசணி விதைகள்",
      price: "279.99",
      stock: 55,
      imageUrl: "https://images.unsplash.com/photo-1587049016823-69ef9d68d301"
    });

    this.products.set(8, {
      id: 8,
      name: "Tomato Seeds",
      nameTA: "தக்காளி விதைகள்",
      category: "SEEDS",
      description: "High-quality tomato seeds",
      descriptionTA: "உயர்தர தக்காளி விதைகள்",
      price: "149.99",
      stock: 100,
      imageUrl: "https://images.unsplash.com/photo-1592841200221-a6898f307baa"
    });

    this.products.set(9, {
      id: 9,
      name: "Peanut Seeds",
      nameTA: "நிலக்கடலை விதைகள்",
      category: "SEEDS",
      description: "Premium quality peanut seeds",
      descriptionTA: "உயர்தர நிலக்கடலை விதைகள்",
      price: "189.99",
      stock: 70,
      imageUrl: "https://images.unsplash.com/photo-1567892320421-1c657571ea4a"
    });

  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user = { ...insertUser, id, isDealer: false };
    this.users.set(id, user);
    return user;
  }

  async getDealers(): Promise<Dealer[]> {
    return Array.from(this.dealers.values());
  }

  async getDealer(id: number): Promise<Dealer | undefined> {
    return this.dealers.get(id);
  }

  async createDealer(dealer: Omit<Dealer, "id">): Promise<Dealer> {
    const id = this.currentId++;
    const newDealer = { ...dealer, id };
    this.dealers.set(id, newDealer);
    return newDealer;
  }

  async getShops(): Promise<Shop[]> {
    return Array.from(this.shops.values());
  }

  async getShop(id: number): Promise<Shop | undefined> {
    return this.shops.get(id);
  }

  async createShop(shop: Omit<Shop, "id">): Promise<Shop> {
    const id = this.currentId++;
    const newShop = { ...shop, id };
    this.shops.set(id, newShop);
    return newShop;
  }

  async getDiseases(): Promise<Disease[]> {
    return Array.from(this.diseases.values());
  }

  async getDisease(id: number): Promise<Disease | undefined> {
    return this.diseases.get(id);
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(product: Omit<Product, "id">): Promise<Product> {
    const id = this.currentId++;
    const newProduct = { ...product, id };
    this.products.set(id, newProduct);
    return newProduct;
  }

  async createOrder(
    userId: number,
    items: Array<{ productId: number; quantity: number }>,
    shippingAddress: string
  ): Promise<Order> {
    const orderId = this.currentId++;
    let total = 0;

    // Create order items and calculate total
    for (const item of items) {
      const product = await this.getProduct(item.productId);
      if (!product) throw new Error(`Product ${item.productId} not found`);
      if (product.stock < item.quantity) throw new Error(`Insufficient stock for ${product.name}`);

      const orderItem: OrderItem = {
        id: this.currentId++,
        orderId,
        productId: item.productId,
        quantity: item.quantity,
        price: product.price,
      };

      this.orderItems.set(orderItem.id, orderItem);
      total += Number(product.price) * item.quantity;
    }

    const order: Order = {
      id: orderId,
      userId,
      status: "PENDING",
      total: total.toString(),
      createdAt: new Date().toISOString(),
      shippingAddress,
    };

    this.orders.set(orderId, order);
    return order;
  }

  async getOrders(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(order => order.userId === userId);
  }

  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return Array.from(this.orderItems.values()).filter(item => item.orderId === orderId);
  }

  async updateUserLanguage(userId: number, language: string): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");

    const updatedUser = { ...user, language };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
}

export const storage = new MemStorage();