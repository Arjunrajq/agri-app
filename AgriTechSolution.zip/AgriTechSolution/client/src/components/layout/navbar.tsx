import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Leaf } from "lucide-react";
import LanguageSwitcher from "./language-switcher";

export default function Navbar() {
  const { user, logoutMutation } = useAuth();

  if (!user) return null;

  const getLabel = (en: string, ta: string) => user.language === "ta" ? ta : en;

  return (
    <nav className="border-b bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <Link href="/" className="flex-shrink-0 flex items-center">
              <Leaf className="h-8 w-8 text-primary" />
              <span className="ml-2 text-xl font-bold text-primary">AgriTech</span>
            </Link>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              <Link href="/dealers" className="inline-flex items-center px-1 pt-1 text-sm font-medium text-gray-900">
                {getLabel("Dealers", "விற்பனையாளர்கள்")}
              </Link>
              <Link href="/shops" className="inline-flex items-center px-1 pt-1 text-sm font-medium text-gray-900">
                {getLabel("Shops", "கடைகள்")}
              </Link>
              <Link href="/store" className="inline-flex items-center px-1 pt-1 text-sm font-medium text-gray-900">
                {getLabel("Store", "கடை")}
              </Link>
              <Link href="/disease-detection" className="inline-flex items-center px-1 pt-1 text-sm font-medium text-gray-900">
                {getLabel("Disease Detection", "நோய் கண்டறிதல்")}
              </Link>
              <Link href="/weather-management" className="inline-flex items-center px-1 pt-1 text-sm font-medium text-gray-900">
                {getLabel("Weather Management", "வானிலை மேலாண்மை")}
              </Link>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <LanguageSwitcher />
            <span className="text-sm text-gray-600">
              {getLabel("Welcome", "வணக்கம்")}, {user.username}
            </span>
            <Button
              variant="outline"
              onClick={() => logoutMutation.mutate()}
              disabled={logoutMutation.isPending}
            >
              {getLabel("Logout", "வெளியேறு")}
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}