import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Languages } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function LanguageSwitcher() {
  const { user } = useAuth();

  const toggleLanguage = async () => {
    const newLang = user?.language === "en" ? "ta" : "en";
    await apiRequest("PATCH", "/api/user/language", { language: newLang });
    queryClient.invalidateQueries({ queryKey: ["/api/user"] });
  };

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={toggleLanguage}
      className="w-10 h-10"
    >
      <Languages className="h-4 w-4" />
      <span className="ml-2 text-xs">{user?.language?.toUpperCase()}</span>
    </Button>
  );
}
