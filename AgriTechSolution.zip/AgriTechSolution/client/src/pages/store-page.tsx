import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ShoppingCart, Plus, Minus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Product } from "@shared/schema";

type CartItem = {
  productId: number;
  quantity: number;
  product: Product;
};

export default function StorePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [address, setAddress] = useState("");

  const { data: products } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const addToCart = (product: Product) => {
    setCart((current) => {
      const existing = current.find((item) => item.productId === product.id);
      if (existing) {
        return current.map((item) =>
          item.productId === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...current, { productId: product.id, quantity: 1, product }];
    });
  };

  const updateQuantity = (productId: number, delta: number) => {
    setCart((current) =>
      current
        .map((item) =>
          item.productId === productId
            ? { ...item, quantity: Math.max(0, item.quantity + delta) }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const placeOrder = async () => {
    if (!address) {
      toast({
        title: user?.language === "ta" ? "முகவரி தேவை" : "Address Required",
        description:
          user?.language === "ta"
            ? "விநியோகத்திற்கான முகவரியை உள்ளிடவும்"
            : "Please enter a shipping address",
        variant: "destructive",
      });
      return;
    }

    try {
      await apiRequest("POST", "/api/orders", {
        items: cart.map(({ productId, quantity }) => ({ productId, quantity })),
        shippingAddress: address,
      });

      toast({
        title:
          user?.language === "ta" ? "ஆர்டர் வெற்றி" : "Order Placed Successfully",
        description:
          user?.language === "ta"
            ? "உங்கள் ஆர்டர் வெற்றிகரமாக வைக்கப்பட்டது"
            : "Your order has been placed successfully",
      });

      setCart([]);
      setAddress("");
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
    } catch (error) {
      toast({
        title:
          user?.language === "ta" ? "ஆர்டர் தோல்வி" : "Order Placement Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold mb-8">
        {user?.language === "ta" ? "ஆன்லைன் கடை" : "Online Store"}
      </h1>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <div className="grid sm:grid-cols-2 gap-6">
            {products?.map((product) => (
              <Card key={product.id}>
                <img
                  src={product.imageUrl}
                  alt={user?.language === "ta" ? product.nameTA : product.name}
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <CardHeader>
                  <CardTitle>
                    {user?.language === "ta" ? product.nameTA : product.name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    {user?.language === "ta"
                      ? product.descriptionTA
                      : product.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="font-bold">₹{product.price}</span>
                    <Button onClick={() => addToCart(product)}>
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      {user?.language === "ta" ? "கூடை" : "Add to Cart"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <Card className="h-fit sticky top-8">
          <CardHeader>
            <CardTitle>
              {user?.language === "ta" ? "உங்கள் கூடை" : "Your Cart"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {cart.map(({ product, quantity }) => (
                <div
                  key={product.id}
                  className="flex items-center justify-between"
                >
                  <div>
                    <h3 className="font-medium">
                      {user?.language === "ta" ? product.nameTA : product.name}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      ₹{product.price} x {quantity}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => updateQuantity(product.id, -1)}
                    >
                      <Minus className="w-4 h-4" />
                    </Button>
                    <span className="w-8 text-center">{quantity}</span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => updateQuantity(product.id, 1)}
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}

              {cart.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">
                  {user?.language === "ta"
                    ? "கூடை காலியாக உள்ளது"
                    : "Cart is empty"}
                </p>
              ) : (
                <>
                  <div className="border-t pt-4">
                    <h3 className="font-medium mb-2">
                      {user?.language === "ta"
                        ? "விநியோக முகவரி"
                        : "Shipping Address"}
                    </h3>
                    <Input
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder={
                        user?.language === "ta"
                          ? "முகவரியை உள்ளிடவும்"
                          : "Enter your address"
                      }
                    />
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex justify-between font-bold mb-4">
                      <span>
                        {user?.language === "ta" ? "மொத்தம்" : "Total"}
                      </span>
                      <span>
                        ₹
                        {cart
                          .reduce(
                            (sum, { product, quantity }) =>
                              sum + Number(product.price) * quantity,
                            0
                          )
                          .toFixed(2)}
                      </span>
                    </div>

                    <Button
                      className="w-full"
                      onClick={placeOrder}
                    >
                      {user?.language === "ta" ? "ஆர்டர் செய்" : "Place Order"}
                    </Button>
                  </div>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
