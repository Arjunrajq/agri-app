import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Cloud, Thermometer, Droplets, Wind } from "lucide-react";

type WeatherData = {
  temperature: number;
  humidity: number;
  windSpeed: number;
  description: string;
  recommendations: string[];
};

export default function WeatherManagement() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [location, setLocation] = useState("");

  const { data: weatherData, refetch } = useQuery<WeatherData>({
    queryKey: ["/api/weather", location],
    enabled: false,
  });

  const handleLocationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!location) {
      toast({
        title: user?.language === "ta" ? "இடம் தேவை" : "Location Required",
        description: user?.language === "ta" 
          ? "தயவுசெய்து உங்கள் இடத்தை உள்ளிடவும்"
          : "Please enter your location",
        variant: "destructive",
      });
      return;
    }
    refetch();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold mb-8">
        {user?.language === "ta" ? "வானிலை அடிப்படையிலான பயிர் மேலாண்மை" : "Weather-based Crop Management"}
      </h1>

      <form onSubmit={handleLocationSubmit} className="mb-8">
        <div className="flex gap-4">
          <Input
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder={user?.language === "ta" ? "உங்கள் இடத்தை உள்ளிடவும்" : "Enter your location"}
            className="max-w-md"
          />
          <Button type="submit">
            {user?.language === "ta" ? "வானிலையைக் காட்டு" : "Show Weather"}
          </Button>
        </div>
      </form>

      {weatherData && (
        <div className="grid md:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>
                {user?.language === "ta" ? "தற்போதைய வானிலை" : "Current Weather"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Thermometer className="h-5 w-5 text-orange-500" />
                  <span>
                    {user?.language === "ta" ? "வெப்பநிலை" : "Temperature"}: {weatherData.temperature}°C
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-blue-500" />
                  <span>
                    {user?.language === "ta" ? "ஈரப்பதம்" : "Humidity"}: {weatherData.humidity}%
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Wind className="h-5 w-5 text-gray-500" />
                  <span>
                    {user?.language === "ta" ? "காற்றின் வேகம்" : "Wind Speed"}: {weatherData.windSpeed} m/s
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Cloud className="h-5 w-5 text-sky-500" />
                  <span>
                    {user?.language === "ta" ? "விளக்கம்" : "Description"}: {weatherData.description}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>
                {user?.language === "ta" ? "பயிர் பரிந்துரைகள்" : "Crop Recommendations"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="list-disc list-inside space-y-2">
                {weatherData.recommendations.map((recommendation, index) => (
                  <li key={index} className="text-sm">
                    {recommendation}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
