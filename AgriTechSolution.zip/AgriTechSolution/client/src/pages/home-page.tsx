import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Tractor, Store, Leaf } from "lucide-react";

export default function HomePage() {
  const { data: dealers } = useQuery<any[]>({
    queryKey: ["/api/dealers"],
  });

  const { data: shops } = useQuery<any[]>({
    queryKey: ["/api/shops"],
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div
        className="rounded-lg bg-cover bg-center mb-8 p-8 text-white relative overflow-hidden"
        style={{
          backgroundImage:
            'url("https://images.unsplash.com/photo-1621470549142-28627b7eed34")',
        }}
      >
        <div className="absolute inset-0 bg-primary/70" />
        <div className="relative">
          <h1 className="text-4xl font-bold mb-4">Welcome to AgriTech</h1>
          <p className="text-lg max-w-2xl">
            Your complete agriculture management platform. Find dealers, locate
            shops, and detect crop diseases all in one place.
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <Link href="/dealers">
          <Card className="cursor-pointer hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Tractor className="mr-2 h-6 w-6" />
                Dealers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Find and connect with agriculture dealers in your area.
              </p>
              <p className="text-sm font-medium">
                {dealers?.length || 0} dealers available
              </p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/shops">
          <Card className="cursor-pointer hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Store className="mr-2 h-6 w-6" />
                Shops
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Locate fertilizer and equipment shops near you.
              </p>
              <p className="text-sm font-medium">
                {shops?.length || 0} shops listed
              </p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/disease-detection">
          <Card className="cursor-pointer hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Leaf className="mr-2 h-6 w-6" />
                Disease Detection
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Scan and identify crop diseases instantly.
              </p>
              <p className="text-sm font-medium">Simple image upload</p>
            </CardContent>
          </Card>
        </Link>
      </div>
    </div>
  );
}
