import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Disease } from "@shared/schema";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Upload, Loader2 } from "lucide-react";

export default function DiseaseDetection() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);

  const { data: diseases } = useQuery<Disease[]>({
    queryKey: ["/api/diseases"],
  });

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDetect = () => {
    // Simulate detection process
    setTimeout(() => {
      setShowResult(true);
    }, 1500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold mb-8">Crop Disease Detection</h1>

      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Upload Image</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                {previewUrl ? (
                  <img
                    src={previewUrl}
                    alt="Preview"
                    className="mx-auto max-h-64 rounded-lg"
                  />
                ) : (
                  <div className="text-gray-500">
                    <Upload className="mx-auto h-12 w-12 mb-4" />
                    <p>Upload a clear image of the affected crop</p>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-4">
                <Input
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="flex-1"
                />
                <Button
                  onClick={handleDetect}
                  disabled={!selectedFile}
                  className="whitespace-nowrap"
                >
                  Detect Disease
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Common Crop Diseases</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {diseases?.map((disease) => (
                <div key={disease.id} className="flex gap-4">
                  <img
                    src={disease.imageUrl}
                    alt={disease.name}
                    className="w-24 h-24 object-cover rounded-lg"
                  />
                  <div>
                    <h3 className="font-medium">{disease.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      {disease.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <AlertDialog open={showResult} onOpenChange={setShowResult}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Detection Result</AlertDialogTitle>
            <AlertDialogDescription>
              <div className="space-y-4">
                <p>Based on the image analysis:</p>
                <div className="p-4 bg-muted rounded-lg">
                  <h4 className="font-medium text-lg mb-2">Leaf Blight</h4>
                  <p className="text-sm mb-4">
                    Common fungal disease affecting crop leaves.
                  </p>
                  <div className="space-y-2 text-sm">
                    <p>
                      <strong>Symptoms:</strong> Yellow patches, Brown spots,
                      Wilting
                    </p>
                    <p>
                      <strong>Treatment:</strong> Apply fungicide and ensure proper
                      drainage
                    </p>
                  </div>
                </div>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
