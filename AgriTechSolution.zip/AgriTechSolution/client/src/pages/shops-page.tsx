import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shop } from "@shared/schema";
import { Phone, MapPin } from "lucide-react";

export default function ShopsPage() {
  const { data: shops, isLoading } = useQuery<Shop[]>({
    queryKey: ["/api/shops"],
  });

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        Loading...
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold mb-8">Fertilizer Shops</h1>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {shops?.map((shop) => (
          <Card key={shop.id}>
            <CardHeader>
              <CardTitle>{shop.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                {shop.description}
              </p>
              
              <div className="space-y-2">
                <div className="flex items-center text-sm">
                  <Phone className="mr-2 h-4 w-4" />
                  {shop.contact}
                </div>
                <div className="flex items-center text-sm">
                  <MapPin className="mr-2 h-4 w-4" />
                  {shop.address}
                </div>
              </div>

              <div className="mt-4 aspect-video rounded-lg overflow-hidden">
                <iframe
                  width="100%"
                  height="100%"
                  frameBorder="0"
                  style={{ border: 0 }}
                  src={`https://www.google.com/maps/embed/v1/place?key=YOUR_API_KEY&q=${encodeURIComponent(
                    shop.address
                  )}`}
                  allowFullScreen
                />
              </div>
            </CardContent>
          </Card>
        ))}

        {shops?.length === 0 && (
          <p className="text-muted-foreground col-span-full text-center py-8">
            No shops found.
          </p>
        )}
      </div>
    </div>
  );
}
