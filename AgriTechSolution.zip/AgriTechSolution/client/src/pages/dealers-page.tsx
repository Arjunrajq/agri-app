import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dealer } from "@shared/schema";
import { Phone, MapPin, List } from "lucide-react";

export default function DealersPage() {
  const { data: dealers, isLoading } = useQuery<Dealer[]>({
    queryKey: ["/api/dealers"],
  });

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        Loading...
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold mb-8">Agricultural Dealers</h1>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {dealers?.map((dealer) => (
          <Card key={dealer.id}>
            <CardHeader>
              <CardTitle>{dealer.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                {dealer.description}
              </p>
              
              <div className="space-y-2">
                <div className="flex items-center text-sm">
                  <Phone className="mr-2 h-4 w-4" />
                  {dealer.contact}
                </div>
                <div className="flex items-center text-sm">
                  <MapPin className="mr-2 h-4 w-4" />
                  {dealer.location}
                </div>
                <div className="flex items-start text-sm">
                  <List className="mr-2 h-4 w-4 mt-1" />
                  <div>
                    <div className="font-medium mb-1">Services:</div>
                    <ul className="list-disc list-inside pl-2">
                      {dealer.services.map((service, i) => (
                        <li key={i}>{service}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {dealers?.length === 0 && (
          <p className="text-muted-foreground col-span-full text-center py-8">
            No dealers found.
          </p>
        )}
      </div>
    </div>
  );
}
