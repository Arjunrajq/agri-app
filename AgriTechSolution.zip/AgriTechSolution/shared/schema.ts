import { pgTable, text, serial, integer, boolean, jsonb, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isDealer: boolean("is_dealer").default(false),
  language: text("language").default("en").notNull(),
});

export const dealers = pgTable("dealers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  contact: text("contact").notNull(),
  location: text("location").notNull(),
  services: text("services").array().notNull(),
});

export const shops = pgTable("shops", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  address: text("address").notNull(),
  lat: text("lat").notNull(),
  lng: text("lng").notNull(),
  contact: text("contact").notNull(),
});

export const diseases = pgTable("diseases", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  symptoms: text("symptoms").array().notNull(),
  treatment: text("treatment").notNull(),
  imageUrl: text("image_url").notNull(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameTA: text("name_ta").notNull(), 
  category: text("category").notNull(), 
  description: text("description").notNull(),
  descriptionTA: text("description_ta").notNull(),
  price: decimal("price").notNull(),
  stock: integer("stock").notNull(),
  imageUrl: text("image_url").notNull(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  status: text("status").notNull(), 
  total: decimal("total").notNull(),
  createdAt: text("created_at").notNull(),
  shippingAddress: text("shipping_address").notNull(),
});

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  productId: integer("product_id").notNull(),
  quantity: integer("quantity").notNull(),
  price: decimal("price").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertDealerSchema = createInsertSchema(dealers).pick({
  name: true,
  description: true,
  contact: true,
  location: true,
  services: true,
});

export const insertShopSchema = createInsertSchema(shops).pick({
  name: true,
  description: true,
  address: true,
  lat: true,
  lng: true,
  contact: true,
});

export const insertProductSchema = createInsertSchema(products).pick({
  name: true,
  nameTA: true,
  category: true,
  description: true,
  descriptionTA: true,
  price: true,
  stock: true,
  imageUrl: true,
});

export const insertOrderSchema = createInsertSchema(orders).pick({
  shippingAddress: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Dealer = typeof dealers.$inferSelect;
export type Shop = typeof shops.$inferSelect;
export type Disease = typeof diseases.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type OrderItem = typeof orderItems.$inferSelect;